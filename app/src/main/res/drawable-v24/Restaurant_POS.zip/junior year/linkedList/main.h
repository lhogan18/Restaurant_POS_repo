#pragma once
class main
{
public:
	main();
	~main();
};

