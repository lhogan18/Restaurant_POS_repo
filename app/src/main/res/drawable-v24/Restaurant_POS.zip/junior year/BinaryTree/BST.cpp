#include "BST.h"
#include <cmath>

BST::BST()
{
}


BST::~BST()
{
}

void BST::insert(int data)
{
	if (node == NULL)
		this->node = new Node(data);
	else
		this->insert(this->node, data);
}

void BST::insert(Node * treeNode, int data)
{
	if (data < treeNode->Key) {
		if (treeNode->left == NULL)
			treeNode->left = new Node(data);
		else
			this->insert(treeNode->left, data);
	}
	else {
		if (treeNode->right == NULL)
			treeNode->right = new Node(data);
		else
			this->insert(treeNode->right, data);
	}
}

bool BST::isBalanced()
{
	if (isBalanced(this->node) == true)
		return true;
	return false;
}


bool BST::isBalanced(Node * treeNode)
{
	if (!treeNode)
		return true;
	int leftHeight = getHeight(treeNode->left);
	int rightHeight = getHeight(treeNode->right);
	if (abs(leftHeight - rightHeight) > 1)
		return false;
	return isBalanced(treeNode->left) && isBalanced(treeNode->right);
}

int BST::getHeight() {
	return(getHeight(this->node));
}

int BST::getHeight(Node * treeNode)
{
	if(treeNode == NULL) //base case
		return 0;
	int leftHeight = getHeight(treeNode->left); 
	int rightHeight = getHeight(treeNode->right);
	int currentHeight = max(leftHeight, rightHeight) + 1;
	return currentHeight;
}

void BST::deleteBST() {
	return(deleteBST(this->node));
}

void BST::deleteBST(Node * treeNode)
{
	if (treeNode != NULL) {
		deleteBST(treeNode->left);
		deleteBST(treeNode->right);
		delete treeNode;
	}
}


std::vector<int> BST::inOrder() {
	inOrder(this->node);
	return(inList);
}

void BST::inOrder(Node * treeNode)
{
	if (treeNode == NULL)
		return;
	inOrder(treeNode->left); //recur on left child
	inList.push_back(treeNode->Key); //print node
	inOrder(treeNode->right); //recur on right child
}

std::vector<int> BST::preOrder() {
	preOrder(this->node);
	return(preList);
}

void BST::preOrder(Node * treeNode)
{
	if (treeNode == NULL)
		return;
	preList.push_back(treeNode->Key); //print the node
	preOrder(treeNode->left); //recur on let subtree
	preOrder(treeNode->right); //recur on right subtree
}

std::vector<int> BST::postOrder() {
	postOrder(this->node);
	return(postList);
}

void BST::postOrder(Node * treeNode)
{
	if (treeNode == NULL)
		return;
	postOrder(treeNode->left); //recur on left subtree
	postOrder(treeNode->right);// recur on right subtree
	postList.push_back(treeNode->Key);
}


int BST::maxNode() {
	return(maxNode(this->node));
}

int BST::maxNode(Node * treeNode)
{
	Node *current = treeNode;
	while (current->right != NULL)
		current = current->right;
	return (current->Key);
}

int BST::minNode() {
	return(minNode(this->node));
}

int BST::minNode(Node * treeNode)
{
	Node *current = treeNode;
	while (current->left != NULL)
		current = current->left;
	return current->Key;
}
