#pragma once
#include <iostream>
class Node
{
public:
	Node();
	~Node();
	int Key;
	Node * left;
	Node * right;
	Node(int data) : Key(data), left(NULL), right(NULL) {}

};

